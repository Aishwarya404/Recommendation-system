import numpy
import math
import calc_idf

movieList = calc_idf.movieList
userList = calc_idf.userList
ratingList = calc_idf.ratingList
movies = calc_idf.movies
users = calc_idf.users
genres= calc_idf.genres
IDF = calc_idf.IDF
c = calc_idf.c
r = calc_idf.r


p = [[0 for x in range(c)] for y in range(r)] 
total_genres = [0 for y in range(r)]
############################FIND P####################3

for rating in ratingList:
	user = int(rating[0])-1
	row_genre = rating[3].split('|')
############################FIND NUME####################3
	for genre in row_genre:
		genre_index= int(genres.index(genre))
		p[user][genre_index] += int(rating[2])
###########################FIND DENO##########
	total_genres[user] += len(row_genre)*int(rating[2])
############################p = (num/den)*idf
for i in range(r):
	for j in range(c):
		p[i][j] = (float(p[i][j])/float(total_genres[i]))*IDF[j]
 
sum = 0
for i in range(r):
	for j in range(c):
		sum += float(p[i][j])
	# print sum
	for j in range(c):
		# print j
		if sum!= 0:
			p[i][j] = p[i][j]/sum
		# print j
	p[i].append(float(sum)/float(c))
	sum=0 

# for u in p:
# 	print u
# print p[3]
# time python calc_p.py