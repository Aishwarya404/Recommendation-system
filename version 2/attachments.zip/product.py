import numpy
import math
import calc_q
import calc_p
import calc_idf
import prod_sim

movieList = calc_idf.movieList
userList = calc_idf.userList
ratingList = calc_idf.ratingList
movies = calc_idf.movies
users = calc_idf.users
genres= calc_idf.genres
IDF = calc_idf.IDF
c = calc_idf.c
r = calc_idf.r
r_m = calc_idf.r_m
# item based . let target be user 4
# rated is unsorted set of movies watched by target
rated = []
for i in range(len(ratingList)) :
	if ratingList[i][0] == '4':
		rated.append(ratingList[i][1])

enemy1 = []
movieslevel1 = []
for m in movies:
	if m not in rated:
		movieslevel1.append(m)

for i in rated :
	for j in movieslevel1 :
		if j not in enemy1:
			k = prod_sim.findSim(i,j)
			print "first ",k
			if k!=0 and k > 0.9 :
				enemy1.append(j)

print "#############",len(enemy1),enemy1

enemy2 = []
movieslevel2 = []
for m in movies:
	if m not in enemy1:
		movieslevel2.append(m)

for i in enemy1 :
	for j in movieslevel2 :
		if j not in enemy2:
			k = prod_sim.findSim(i,j)
			print "second ",k
			if k!=0 and k > 0 :
				enemy2.append(j)

print "&&&&&&&&&",len(enemy2)


enemy1 = enemy1 + enemy2
recSet = []
remmovies = []
for m in movies:
	if m not in enemy1:
		remmovies.append(m)

for i in enemy1 :
	for j in remmovies :
		if j not in recSet:
			k = prod_sim.findSim(i,j)
			print "last ",k
			if k!=0 and k <= 0 :
				recSet.append(j)

print len(recSet), recSet


# time python product.py